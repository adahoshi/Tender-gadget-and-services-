// BACKEND - This is your database for SPCK
let defaultProducts = [
  {id:1, name:"iPhone 12 - 128GB", cat:"phone", price:250000, old:290000, cond:"Used", desc:"Neatly used, Battery 89%", img:"https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=500", stock:2},
  {id:2, name:"iPhone 13 - 256GB", cat:"phone", price:420000, old:480000, cond:"New", desc:"Brand New, Sealed", img:"https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=500", stock:5},
  {id:3, name:"Samsung S23", cat:"phone", price:380000, old:420000, cond:"New", desc:"256GB, Dual SIM", img:"https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=500", stock:3},
  {id:4, name:"iPhone 11 - 64GB", cat:"phone", price:165000, old:190000, cond:"UK Used", desc:"Clean, Battery 85%", img:"https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=500", stock:1},
];

if(!localStorage.getItem('tender_products')){
  localStorage.setItem('tender_products', JSON.stringify(defaultProducts));
}
if(!localStorage.getItem('tender_orders')){
  localStorage.setItem('tender_orders', JSON.stringify([]));
}

let currentCat = 'all';

function getProducts(){ return JSON.parse(localStorage.getItem('tender_products')); }
function saveProducts(p){ localStorage.setItem('tender_products', JSON.stringify(p)); }

function setCat(c, btn){
  currentCat = c;
  document.querySelectorAll('.cats button').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  showProducts();
}

function showProducts(){
  let grid = document.getElementById('grid');
  if(!grid) return;
  let q = document.getElementById('searchBox').value.toLowerCase();
  let products = getProducts();
  grid.innerHTML = '';
  products.forEach(p=>{
    if(p.stock <= 0) return;
    if((currentCat=='all' || p.cat==currentCat) && p.name.toLowerCase().includes(q)){
      grid.innerHTML += `
      <div class="card">
        <img src="${p.img}">
        <div>
          <span class="badge">${p.cond}</span>
          <h3 style="margin:8px 0 4px">${p.name}</h3>
          <p style="font-size:12px;color:#666;margin:0">${p.desc} • Stock: ${p.stock}</p>
          <div class="price">₦${p.price.toLocaleString()} <span class="old">₦${p.old.toLocaleString()}</span></div>
          <input id="name-${p.id}" placeholder="Your Name">
          <input id="phone-${p.id}" placeholder="Your WhatsApp Number">
          <button class="buy" onclick="orderNow(${p.id})">ORDER NOW</button>
        </div>
      </div>`;
    }
  });
  if(grid.innerHTML=='') grid.innerHTML='<p style="text-align:center">No product for this category yet</p>';
}

function orderNow(id){
  let products = getProducts();
  let p = products.find(x=>x.id==id);
  let cname = document.getElementById('name-'+id).value;
  let cphone = document.getElementById('phone-'+id).value;
  if(!cname || !cphone){ alert('Abeg put your name and number'); return; }
  // BACKEND: Save Order
  let orders = JSON.parse(localStorage.getItem('tender_orders'));
  orders.push({customer:cname, phone:cphone, product:p.name, price:p.price, date:new Date().toLocaleString(), status:'New'});
  localStorage.setItem('tender_orders', JSON.stringify(orders));
  // BACKEND: Reduce Stock
  p.stock = p.stock - 1;
  saveProducts(products);
  // Go WhatsApp
  let msg = `Hello TENDER GADGET AND STORE, I am ${cname}, I want to buy ${p.name} - ₦${p.price}. My number is ${cphone}`;
  window.open('https://wa.me/2349164735395?text='+encodeURIComponent(msg));
  showProducts();
}

if(document.getElementById('grid')) showProducts();